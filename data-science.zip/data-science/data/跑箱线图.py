import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler

# 指定输入文件夹和输出文件夹路径
input_folder_path = r'D:\桌面\数维杯\2.1'  # 包含所有文件的文件夹
output_folder_path = r'D:\桌面\数维杯\2.Boxplots'  # 保存箱线图的文件夹

# 创建输出文件夹（如果不存在）
if not os.path.exists(output_folder_path):
    os.makedirs(output_folder_path)

# 获取所有 adcode 文件
file_list = [file for file in os.listdir(input_folder_path) if file.startswith("adcode2_") and file.endswith(".xlsx")]

# 遍历每个文件并生成箱线图
for file_name in file_list:
    # 获取当前文件的 adcode 值
    adcode_value = file_name.split('_')[1].split('.')[0]  # 获取 adcode 的值部分
    input_file_path = os.path.join(input_folder_path, file_name)
    
    # 读取数据
    data = pd.read_excel(input_file_path)

    # 选择数值型特征
    num_columns = data.select_dtypes(include=['int64', 'float64']).columns

    # 标准化数值特征
    scaler = StandardScaler()
    data[num_columns] = scaler.fit_transform(data[num_columns])

    # 绘制标准化后的箱线图
    plt.figure(figsize=(12, 8))
    data[num_columns].boxplot()
    plt.xticks(rotation=90)
    plt.title(f'Boxplot for Numerical Features After Standardization - adcode {adcode_value}')

    # 保存箱线图到输出文件夹
    output_file_path = os.path.join(output_folder_path, f'boxplot_adcode_{adcode_value}.png')
    plt.savefig(output_file_path)

    # 关闭当前图形，防止内存泄漏
    plt.close()

    print(f"Boxplot for adcode {adcode_value} saved to {output_file_path}")

print("所有区域的箱线图已生成并保存！")
