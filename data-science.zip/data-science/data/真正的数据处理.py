import pandas as pd

# 定义清洗函数
def clean_data(group):
    """
    对每个 adcode 的子集数据进行清洗和处理
    """
    # 填充数值型变量的缺失值（用中位数填充）
    num_columns = ['Total number of households', 'Greening rate', 'Floor area ratio', 
                   'above-ground parking fee（/month USD）']
    for col in num_columns:
        group[col] = group[col].fillna(group[col].median())

    # 删除 'underground parking fee（/month USD）' 列
    group = group.drop(columns=['underground parking fee（/month USD）'], errors='ignore')
    
    # 提取 'parking space' 中的比例部分
    group['parking space ratio'] = group['parking space'].str.extract(r'\((\d+:\d+\.\d+)\)')
    group['parking space ratio'] = group['parking space ratio'].str.split(':').str[1].astype(float)
    group['parking space ratio'] = group['parking space ratio'].fillna(group['parking space ratio'].median())
    group = group.drop(columns=['parking space'], errors='ignore')

    # 确保 'Property management fee' 列是字符串类型（防止其他类型的问题）
    group['Property management fee（/m²/month USD）'] = group['Property management fee（/m²/month USD）'].astype(str)

    # 将 'Property management fee' 列转换为数值型，无法转换的将变为 NaN
    group['Property management fee（/m²/month USD）'] = pd.to_numeric(group['Property management fee（/m²/month USD）'], errors='coerce')

    # 填充缺失值（NaN）为该区域的中位数
    group['Property management fee（/m²/month USD）'] = group['Property management fee（/m²/month USD）'].fillna(group['Property management fee（/m²/month USD）'].median())

    # 填补 Building type 缺失值
    group['Building type'] = group['Building type'].fillna('multi-story')
    group['Building type'] = group['Building type'].str.strip()
    group['Building type'] = group['Building type'].str.replace(r'\s*\|\s*', '|', regex=True)

    # 清理 Building type 中的值：去除 | 两边的空格
    group['Building type'] = group['Building type'].str.replace(r'\s*\|\s*', '|', regex=True)

    # 独热编码
    building_types_split = group['Building type'].str.get_dummies(sep='|')
    group = pd.concat([group, building_types_split], axis=1)

    # 合并重复列（确保独热编码后的列不重复）
    for col in building_types_split.columns:
        if col in group.columns:
            group[col] = group.filter(like=col).max(axis=1)

    # 删除可能重复的列
    group = group.loc[:, ~group.columns.duplicated()]

    # 删除原始 'Building type' 列
    group = group.drop(columns=['Building type'], errors='ignore')

   # 填补 property type 缺失值
    group['property type'] = group['property type'].fillna('other')

    # 针对每个区域的 property type 列进行统计
    # 选择常见的几种类型：'commercial-residential'，'residential'，'villa'
    standard_types = ['commercial-residential', 'residential', 'villa']
    group['property type'] = group['property type'].apply(lambda x: x.strip() if isinstance(x, str) else 'other')  # 去除空格
    group['property type'] = group['property type'].apply(lambda x: x if x in standard_types else 'other')

    # 针对每个 adcode 内的 property type 进行独热编码
    property_types_split = pd.get_dummies(group['property type'], prefix='property_type')
    group = pd.concat([group, property_types_split], axis=1)

    # 删除重复列
    group = group.loc[:, ~group.columns.duplicated()]

    # 删除原始 'property type' 列
    group = group.drop(columns=['property type'], errors='ignore')

    # 确保所有标准列都存在，如果没有则填充为 0
    for col in ['property_type_commercial-residential', 'property_type_residential', 
                'property_type_villa', 'property_type_other']:
        if col not in group.columns:
            group[col] = 0


    # 删除 citycode 列
    group = group.drop(columns=['citycode'], errors='ignore')

    return group

# 加载原始数据
file_path = r'./Appendix 2.xlsx'
data = pd.read_excel(file_path)

# 删除目标变量缺失的行
data = data.dropna(subset=['Price (USD)'])

# 按 adcode 分组清洗和处理
adcode_groups = data.groupby('adcode')
for adcode, group in adcode_groups:
    cleaned_group = clean_data(group)
    # 保存清洗后的数据
    file_name = f'./adcode2_{adcode}.xlsx'
    cleaned_group.to_excel(file_name, index=False)

print("数据清洗完成，并按 adcode 保存为独立文件。")
