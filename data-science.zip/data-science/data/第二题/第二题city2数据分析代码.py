import os
import pandas as pd

# 指定City 2数据文件所在的文件夹路径
input_folder_path = r'D:\桌面\数维杯\Appendix 4'  # 替换为实际文件夹路径
file_list = os.listdir(input_folder_path)

# 初始化一个DataFrame来存储汇总的结果
summary_df = pd.DataFrame(columns=['Service Type', 'Total Facilities', 'Average Density (facilities per km²)', 'Population per Facility'])

# 示例人口数据和区域面积数据（需要根据具体数据补充真实信息）
city2_population = 4082400  # 乌鲁木齐市人口
city2_area_km2 = 13800  # 乌鲁木齐市的总面积（平方公里）

# 遍历每个文件并进行分析
for file_name in file_list:
    file_path = os.path.join(input_folder_path, file_name)
   
    # 读取文件
    if file_name.endswith('.csv'):
        try:
            data = pd.read_csv(file_path, encoding='utf-8')
        except UnicodeDecodeError:
            # 如果UTF-8编码失败，尝试用ISO-8859-1编码读取
            try:
                data = pd.read_csv(file_path, encoding='ISO-8859-1')
            except UnicodeDecodeError:
                # 如果ISO-8859-1编码失败，尝试用GBK编码读取
                data = pd.read_csv(file_path, encoding='GBK')
    else:
        continue  # 跳过非CSV文件
   
    # 基于文件名提取服务类型
    service_type = file_name.replace('.csv', '').replace(' data', '').replace('_', ' ').title()

    # 清洗数据 - 这里以删除缺失值为例，具体的清洗步骤可以更复杂
    data_cleaned = data
   
    # 统计设施总数
    total_facilities = data_cleaned.shape[0]
   
    # 计算服务密度（每平方公里的设施数量）
    avg_density = total_facilities / city2_area_km2
   
    # 计算每个设施服务的人口比例
    population_per_facility = city2_population / total_facilities if total_facilities > 0 else None
   
    # 将结果存储到summary DataFrame中
    summary_df = pd.concat([summary_df, pd.DataFrame([{
        'Service Type': service_type,
        'Total Facilities': total_facilities,
        'Average Density (facilities per km²)': avg_density,
        'Population per Facility': population_per_facility
    }])], ignore_index=True)

# 将汇总结果保存到Excel文件中
output_path = r'D:\桌面\数维杯\Appendix 4\City2_Summary.xlsx'
summary_df.to_excel(output_path, index=False)

print("City 2 服务领域的统计分析完成，结果已保存到:", output_path)
