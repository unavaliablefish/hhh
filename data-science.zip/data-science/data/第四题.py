import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os

# 读取两个城市的汇总数据
file_city1 = r'D:\桌面\数维杯\Appendix 3\City1_Summary.xlsx'
file_city2 = r'D:\桌面\数维杯\Appendix 4\City2_Summary.xlsx'

city1_data = pd.read_excel(file_city1)
city2_data = pd.read_excel(file_city2)

# 给两个城市的数据加上标识列
city1_data['City'] = 'City 1'
city2_data['City'] = 'City 2'

# 确保两个城市的数据具有相同的服务类型并且顺序一致
city1_data = city1_data.sort_values(by='Service Type').reset_index(drop=True)
city2_data = city2_data.sort_values(by='Service Type').reset_index(drop=True)

# 合并两个城市的数据
combined_data = pd.concat([city1_data, city2_data], ignore_index=True)

# 确保合并后的数据一致
print(combined_data.head())

# 设置输出文件夹路径（用于保存图表）
output_folder_path = r'D:\桌面\数维杯\Visualizations'

# 确保保存图表的目录存在
if not os.path.exists(output_folder_path):
    os.makedirs(output_folder_path)

# 生成柱状图比较两个城市的设施总数
plt.figure(figsize=(10, 6))
for service_type in combined_data['Service Type'].unique():
    subset = combined_data[combined_data['Service Type'] == service_type]
    plt.bar(subset['City'] + ' - ' + service_type, subset['Total Facilities'], label=service_type)

plt.xlabel('Service Type (City-wise)')
plt.ylabel('Total Facilities')
plt.xticks(rotation=90)
plt.title('Total Facilities Comparison Between City 1 and City 2')
plt.tight_layout()
plt.savefig(os.path.join(output_folder_path, 'total_facilities_comparison.png'))
plt.show()

# 生成条形图比较设施密度
plt.figure(figsize=(10, 6))
width = 0.35  # 条形图的宽度
service_types = city1_data['Service Type'].unique()
x = np.arange(len(service_types))

density_city1 = city1_data['Average Density (facilities per km²)'].values
density_city2 = city2_data['Average Density (facilities per km²)'].values

plt.bar(x - width/2, density_city1, width, label='City 1')
plt.bar(x + width/2, density_city2, width, label='City 2')

plt.xlabel('Service Type')
plt.ylabel('Average Density (facilities per km²)')
plt.xticks(ticks=x, labels=service_types, rotation=90)
plt.title('Average Density Comparison Between City 1 and City 2')
plt.legend()
plt.tight_layout()
plt.savefig(os.path.join(output_folder_path, 'average_density_comparison.png'))
plt.show()

# 生成散点图比较每个设施服务的人口比例
plt.figure(figsize=(10, 6))
for service_type in service_types:
    subset_city1 = city1_data[city1_data['Service Type'] == service_type]
    subset_city2 = city2_data[city2_data['Service Type'] == service_type]
    
    plt.scatter(subset_city1['Service Type'], subset_city1['Population per Facility'], color='blue', label='City 1 - ' + service_type)
    plt.scatter(subset_city2['Service Type'], subset_city2['Population per Facility'], color='orange', label='City 2 - ' + service_type)

plt.xlabel('Service Type')
plt.ylabel('Population per Facility')
plt.xticks(rotation=90)
plt.title('Population per Facility Comparison Between City 1 and City 2')
plt.tight_layout()
plt.savefig(os.path.join(output_folder_path, 'population_per_facility_comparison.png'))
plt.show()
