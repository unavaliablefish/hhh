import pandas as pd

# 读取合并后的汇总数据
city1_path = r'D:\桌面\数维杯\Appendix 3\City1_Summary.xlsx'
city2_path = r'D:\桌面\数维杯\Appendix 4\City2_Summary.xlsx'

city1_df = pd.read_excel(city1_path)
city2_df = pd.read_excel(city2_path)

# 添加城市列以便区分
city1_df['City'] = 'City 1'
city2_df['City'] = 'City 2'

# 确保两个数据集按相同的服务类型顺序对齐
all_service_types = sorted(pd.concat([city1_df['Service Type'], city2_df['Service Type']]).unique())

city1_df = city1_df.set_index('Service Type').reindex(all_service_types).reset_index()
city2_df = city2_df.set_index('Service Type').reindex(all_service_types).reset_index()

# 计算设施总数差异、设施密度差异、人口服务差异
comparison_df = pd.DataFrame()
comparison_df['Service Type'] = city1_df['Service Type']

# 1. 设施总数差异
comparison_df['City 1 Total Facilities'] = city1_df['Total Facilities']
comparison_df['City 2 Total Facilities'] = city2_df['Total Facilities']
comparison_df['Total Facilities Difference'] = city1_df['Total Facilities'] - city2_df['Total Facilities']
comparison_df['Total Facilities % Difference'] = (comparison_df['Total Facilities Difference'] / ((city1_df['Total Facilities'] + city2_df['Total Facilities']) / 2)) * 100

# 2. 设施密度差异
comparison_df['City 1 Density (facilities per km²)'] = city1_df['Average Density (facilities per km²)']
comparison_df['City 2 Density (facilities per km²)'] = city2_df['Average Density (facilities per km²)']
comparison_df['Density Difference'] = city1_df['Average Density (facilities per km²)'] - city2_df['Average Density (facilities per km²)']
comparison_df['Density % Difference'] = (comparison_df['Density Difference'] / ((city1_df['Average Density (facilities per km²)'] + city2_df['Average Density (facilities per km²)']) / 2)) * 100

# 3. 人口服务差异
comparison_df['City 1 Population per Facility'] = city1_df['Population per Facility']
comparison_df['City 2 Population per Facility'] = city2_df['Population per Facility']
comparison_df['Population per Facility Difference'] = city1_df['Population per Facility'] - city2_df['Population per Facility']
comparison_df['Population per Facility % Difference'] = (comparison_df['Population per Facility Difference'] / ((city1_df['Population per Facility'] + city2_df['Population per Facility']) / 2)) * 100

# 显示比较结果
print(comparison_df)

# 保存比较结果为 Excel 文件
comparison_output_path = r'D:\桌面\数维杯\City_Comparison_Summary.xlsx'
comparison_df.to_excel(comparison_output_path, index=False)
print(f"对比结果已保存到：{comparison_output_path}")
