import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 读取 City 1 和 City 2 的汇总数据
city1_path = r'D:\桌面\数维杯\Appendix 3\City1_Summary.xlsx'
city2_path = r'D:\桌面\数维杯\Appendix 4\City2_Summary.xlsx'

city1_df = pd.read_excel(city1_path)
city2_df = pd.read_excel(city2_path)

# 添加城市列以便区分
city1_df['City'] = 'City 1'
city2_df['City'] = 'City 2'

# 确保两个数据集按相同的服务类型顺序对齐
all_service_types = sorted(pd.concat([city1_df['Service Type'], city2_df['Service Type']]).unique())

city1_df = city1_df.set_index('Service Type').reindex(all_service_types).reset_index()
city2_df = city2_df.set_index('Service Type').reindex(all_service_types).reset_index()

# 合并数据
combined_df = pd.concat([city1_df, city2_df], ignore_index=True)

# 绘制可视化图表

# 1. 比较两个城市的设施总数
service_types = city1_df['Service Type']
facilities_city1 = city1_df['Total Facilities']
facilities_city2 = city2_df['Total Facilities']

x = np.arange(len(service_types))  # 横坐标
width = 0.35  # 柱的宽度

plt.figure(figsize=(12, 6))
plt.bar(x - width/2, facilities_city1, width, label='City 1')
plt.bar(x + width/2, facilities_city2, width, label='City 2')

plt.xlabel('Service Type')
plt.ylabel('Total Facilities')
plt.title('Total Facilities by Service Type in City 1 and City 2')
plt.xticks(x, service_types, rotation=90)
plt.legend()
plt.tight_layout()
plt.savefig(r'D:\桌面\数维杯\Total_Facilities_Comparison.png')
plt.show()

# 2. 比较两个城市的设施密度
density_city1 = city1_df['Average Density (facilities per km²)']
density_city2 = city2_df['Average Density (facilities per km²)']

plt.figure(figsize=(12, 6))
plt.bar(x - width/2, density_city1, width, label='City 1')
plt.bar(x + width/2, density_city2, width, label='City 2')

plt.xlabel('Service Type')
plt.ylabel('Average Density (facilities per km²)')
plt.title('Average Density of Facilities by Service Type in City 1 and City 2')
plt.xticks(x, service_types, rotation=90)
plt.legend()
plt.tight_layout()
plt.savefig(r'D:\桌面\数维杯\Density_Comparison.png')
plt.show()

# 3. 比较每个设施服务的人口比例
population_per_facility_city1 = city1_df['Population per Facility']
population_per_facility_city2 = city2_df['Population per Facility']

plt.figure(figsize=(12, 6))
plt.bar(x - width/2, population_per_facility_city1, width, label='City 1')
plt.bar(x + width/2, population_per_facility_city2, width, label='City 2')

plt.xlabel('Service Type')
plt.ylabel('Population per Facility')
plt.title('Population per Facility by Service Type in City 1 and City 2')
plt.xticks(x, service_types, rotation=90)
plt.legend()
plt.tight_layout()
plt.savefig(r'D:\桌面\数维杯\Population_Per_Facility_Comparison.png')
plt.show()
