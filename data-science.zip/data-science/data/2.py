import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import MinMaxScaler

# 假设你已经有City 1和City 2的数据
city1_file_path = r'D:\桌面\数维杯\Appendix 3\City1_Summary.xlsx'  # 替换为City 1的实际路径
city2_file_path = r'D:\桌面\数维杯\Appendix 4\City2_Summary.xlsx'  # 替换为City 2的实际路径

# 读取数据
city1_data = pd.read_excel(city1_file_path)
city2_data = pd.read_excel(city2_file_path)

# 添加城市名称列
city1_data['City'] = 'City 1'
city2_data['City'] = 'City 2'

# 合并两个城市的数据
combined_data = pd.concat([city1_data, city2_data], ignore_index=True)

# 确认合并后的数据框包含 'City' 列
print(combined_data.columns)

# 标准化处理
scaler = MinMaxScaler()
columns_to_normalize = ['Total Facilities', 'Average Density (facilities per km²)', 'Population per Facility']
combined_data[columns_to_normalize] = scaler.fit_transform(combined_data[columns_to_normalize])

# 设定权重
weights = {
    'Total Facilities': 0.3,
    'Average Density (facilities per km²)': 0.4,
    'Population per Facility': 0.3
}

# 构建综合评分
combined_data['Resilience Score'] = (
    weights['Total Facilities'] * combined_data['Total Facilities'] +
    weights['Average Density (facilities per km²)'] * combined_data['Average Density (facilities per km²)'] +
    weights['Population per Facility'] * (1 - combined_data['Population per Facility'])
)

# 根据城市分组，计算每个城市的平均韧性评分
city_scores = combined_data.groupby('City')['Resilience Score'].mean().reset_index()
city_scores.columns = ['City', 'Average Resilience Score']

# 打印城市的韧性得分
print(city_scores)
