import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# 1. 导入数据
file_path_combined = r'D:\桌面\数维杯\Combined_City_Resilience_Scores.xlsx'  # 合并后的City 1和City 2数据文件

# 读取数据
combined_data = pd.read_excel(file_path_combined)

# 分离City 1和City 2的数据
city1_data = combined_data[combined_data['City'] == 'City 1']
city2_data = combined_data[combined_data['City'] == 'City 2']

# 确保 Service Type 一致性
city1_service_types = set(city1_data['Service Type'])
city2_service_types = set(city2_data['Service Type'])

# 找到两个城市共有的 Service Type
common_service_types = city1_service_types.intersection(city2_service_types)

# 过滤数据，只保留共有的 Service Type
city1_data_filtered = city1_data[city1_data['Service Type'].isin(common_service_types)].sort_values(by='Service Type').reset_index(drop=True)
city2_data_filtered = city2_data[city2_data['Service Type'].isin(common_service_types)].sort_values(by='Service Type').reset_index(drop=True)

# 确保两个城市的 Service Type 列完全匹配
assert all(city1_data_filtered['Service Type'] == city2_data_filtered['Service Type']), "Service Type 不匹配，请检查排序过程"

# 准备雷达图的数据
def plot_radar_chart(city1_data, city2_data, scenario):
    categories = city1_data['Service Type'].tolist()  # 服务类型列表
    city1_scores = city1_data[f'topsis_score_{scenario}'].tolist()
    city2_scores = city2_data[f'topsis_score_{scenario}'].tolist()
    
    # 设置角度，确保雷达图是闭合的
    num_vars = len(categories)
    angles = np.linspace(0, 2 * np.pi, num_vars, endpoint=False).tolist()
    angles += angles[:1]
    
    # 确保分数数据与角度保持一致
    city1_scores += city1_scores[:1]
    city2_scores += city2_scores[:1]

    # 绘制雷达图
    fig, ax = plt.subplots(figsize=(8, 8), subplot_kw=dict(polar=True))
    
    # 绘制两个城市的数据填充
    ax.plot(angles, city1_scores, color='blue', linewidth=2, linestyle='solid', label='City 1')
    ax.fill(angles, city1_scores, color='blue', alpha=0.25)
    
    ax.plot(angles, city2_scores, color='red', linewidth=2, linestyle='solid', label='City 2')
    ax.fill(angles, city2_scores, color='red', alpha=0.25)
    
    # 设置图例、标题等
    ax.set_yticklabels([])  # 不显示辐射刻度线
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(categories, fontsize=10)  # 保证标签为服务类型列表，且不会偏移
    plt.title(f'Comparison for {scenario} Scenario', size=20, color='black', y=1.1)
    plt.legend()
    plt.show()

# 使用雷达图对比 City 1 和 City 2 在极端天气下的表现
plot_radar_chart(city1_data_filtered, city2_data_filtered, 'extreme_weather')
# 可以重复调用这个函数，传入 'emergency' 和 'sustainable' 来绘制其他情景下的对比图
plot_radar_chart(city1_data_filtered, city2_data_filtered, 'emergency')
plot_radar_chart(city1_data_filtered, city2_data_filtered, 'sustainable')
