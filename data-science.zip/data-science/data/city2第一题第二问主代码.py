import pandas as pd

# 假设的一些基础数据
gdp_2022 = 3691.57  # 2022年乌鲁木齐市GDP，单位：亿元
gdp_2023 = 3893.22  # 假设的2023年乌鲁木齐市GDP，单位：亿元（可根据实际数据更改）
population_2022 = 4055000  # 2022年乌鲁木齐总人口，单位：人
population_2023 = 4082400  # 假设的2023年乌鲁木齐总人口，单位：人（可根据实际数据更改）
avg_area_per_person_2022 = 34.2  # 2022年人均住房面积，单位：平方米

# 房屋区域数据（使用之前分析的区域表）
file_path = r'D:\桌面\数维杯\2.1\combined_city_data.xlsx'  # 替换为实际文件路径
data = pd.read_excel(file_path)

# 1. 计算每个区的总户数和平均每户人口数量
total_households = data['Total number of households'].sum()  # 总户数
avg_persons_per_household = population_2022 / total_households  # 平均每户人口数量

# 打印检查每户人口的平均值
print(f"平均每户人口数量: {avg_persons_per_household:.2f}")

# 2. 计算现有住房的总面积需求（2022年）
total_area_needed_2022 = population_2022 * avg_area_per_person_2022  # 现有住房总面积需求（平方米）

# 3. 根据GDP变化调整人均住房面积
gdp_growth_rate = (gdp_2023 - gdp_2022) / gdp_2022  # GDP 增长率
adjustment_factor = 1 + 0.05 * gdp_growth_rate  # 假设GDP每增长1%，人均住房面积增加0.05%
avg_area_per_person_2023 = avg_area_per_person_2022 * adjustment_factor  # 调整后的2023年人均住房面积

# 打印检查人均住房面积的变化
print(f"2022年人均住房面积: {avg_area_per_person_2022} 平方米")
print(f"2023年人均住房面积: {avg_area_per_person_2023:.2f} 平方米")

# 4. 计算2023年住房需求面积
total_area_needed_2023 = population_2023 * avg_area_per_person_2023  # 2023年住房需求总面积（平方米）

# 5. 计算每一户的平均住房面积需求
avg_household_area_needed = avg_persons_per_household * avg_area_per_person_2023  # 每户的平均住房面积需求（平方米）

# 6. 计算2023年需要增加或减少的住房套数
area_difference = total_area_needed_2023 - total_area_needed_2022  # 总面积的增加或减少
housing_units_change = area_difference / avg_household_area_needed  # 需要增加或减少的住房套数

# 打印最终结果
if housing_units_change > 0:
    print(f"2023年需要增加的住房数量：{housing_units_change:.0f} 套")
else:
    print(f"2023年需要减少的住房数量：{abs(housing_units_change):.0f} 套")
