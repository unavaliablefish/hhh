import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler

# 读取数据
file_path_city1 = r'D:\桌面\数维杯\Appendix 3\City1_Summary.xlsx'
file_path_city2 = r'D:\桌面\数维杯\Appendix 4\City2_Summary.xlsx'

city1_data = pd.read_excel(file_path_city1)
city2_data = pd.read_excel(file_path_city2)

# 为两个城市的数据添加 "City" 列，方便后续标识
city1_data['City'] = 'City 1'
city2_data['City'] = 'City 2'

# 合并数据
combined_data = pd.concat([city1_data, city2_data], ignore_index=True)

# 定义特征的权重和类型
weights_extreme_weather = {
    'Total Facilities': 0.2,
    'Average Density (facilities per km²)': 0.4,
    'Population per Facility': 0.4
}

weights_emergency = {
    'Total Facilities': 0.3,
    'Average Density (facilities per km²)': 0.5,
    'Population per Facility': 0.2
}

weights_sustainable_development = {
    'Total Facilities': 0.3,
    'Average Density (facilities per km²)': 0.3,
    'Population per Facility': 0.4
}

benefit_criteria = ['Total Facilities', 'Average Density (facilities per km²)']
cost_criteria = ['Population per Facility']

# 定义TOPSIS计算函数
def calculate_topsis_score(data, weights, benefit_criteria, cost_criteria):
    # 标准化处理（合并后进行标准化，以保持相对量级的对比）
    scaler = MinMaxScaler()
    columns_to_normalize = list(weights.keys())
    data_normalized = pd.DataFrame(scaler.fit_transform(data[columns_to_normalize]), columns=[col + '_normalized' for col in columns_to_normalize])
    
    # 将标准化后的数据与原始数据合并
    data = pd.concat([data.reset_index(drop=True), data_normalized.reset_index(drop=True)], axis=1)

    # 构建加权标准化决策矩阵
    for col in weights:
        data[col + '_weighted'] = data[col + '_normalized'] * weights[col]

    # 确定理想解和负理想解
    ideal_solution = []
    negative_ideal_solution = []
    for col in weights:
        if col in benefit_criteria:
            ideal_solution.append(data[col + '_weighted'].max())
            negative_ideal_solution.append(data[col + '_weighted'].min())
        elif col in cost_criteria:
            ideal_solution.append(data[col + '_weighted'].min())
            negative_ideal_solution.append(data[col + '_weighted'].max())

    ideal_solution = np.array(ideal_solution)
    negative_ideal_solution = np.array(negative_ideal_solution)

    # 计算每个方案到理想解和负理想解的欧氏距离
    def calculate_euclidean_distance(row, target):
        return np.sqrt(np.sum((row - target) ** 2))

    # 计算距离
    data['distance_to_ideal'] = data.apply(lambda row: calculate_euclidean_distance(
        row[[col + '_weighted' for col in weights]], ideal_solution), axis=1)

    data['distance_to_negative_ideal'] = data.apply(lambda row: calculate_euclidean_distance(
        row[[col + '_weighted' for col in weights]], negative_ideal_solution), axis=1)

    # 计算每个方案的相对接近度
    data['topsis_score'] = data['distance_to_negative_ideal'] / (data['distance_to_ideal'] + data['distance_to_negative_ideal'])

    return data

# 分别计算三种情况的 TOPSIS 评分
topsis_extreme_weather = calculate_topsis_score(combined_data, weights_extreme_weather, benefit_criteria, cost_criteria)
topsis_emergency = calculate_topsis_score(combined_data, weights_emergency, benefit_criteria, cost_criteria)
topsis_sustainable = calculate_topsis_score(combined_data, weights_sustainable_development, benefit_criteria, cost_criteria)

# 将三种情况下的 TOPSIS 评分保存到原数据中
combined_data['topsis_score_extreme_weather'] = topsis_extreme_weather['topsis_score']
combined_data['topsis_score_emergency'] = topsis_emergency['topsis_score']
combined_data['topsis_score_sustainable'] = topsis_sustainable['topsis_score']

# 保存所有评分到一个新Excel文件
combined_file_path = r'D:\桌面\数维杯\Combined_City_Resilience_Scores.xlsx'
combined_data.to_excel(combined_file_path, index=False)

print("TOPSIS 评分已成功合并并保存到新文件 Combined_City_Resilience_Scores.xlsx！")
