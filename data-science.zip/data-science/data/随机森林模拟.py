import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.metrics import mean_absolute_error
from sklearn.preprocessing import StandardScaler

# 指定文件夹路径
input_folder_path = r'D:\桌面\数维杯\2.1'  # 包含所有文件的文件夹
output_folder_path = r'D:\桌面\数维杯\2.2'  # 用于保存预测结果的文件夹

# 获取所有 adcode 文件
file_list = [file for file in os.listdir(input_folder_path) if file.startswith("adcode2_") and file.endswith(".xlsx")]

# 遍历每个文件并进行预测
for file_name in file_list:
    # 获取当前文件的 adcode 值
    adcode_value = file_name.split('_')[1].split('.')[0]  # 获取 adcode 的值部分
    input_file_path = os.path.join(input_folder_path, file_name)
    
    # 读取数据
    data = pd.read_excel(input_file_path)

    # 去除异常值的方法：调整 IQR 方法
    num_columns = data.select_dtypes(include=['int64', 'float64']).columns
    for col in num_columns:
        Q1 = data[col].quantile(0.25)
        Q3 = data[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 2.0 * IQR  # 调整 IQR 倍数
        upper_bound = Q3 + 2.0 * IQR
        data = data[(data[col] >= lower_bound) & (data[col] <= upper_bound)]

    # 准备数据：分割特征和目标
    X = data.drop(columns=['Price (USD)', 'adcode'])
    y = data['Price (USD)']

    # 特征标准化
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    # 拆分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # 随机森林模型 - 超参数调优
    param_grid = {
        'n_estimators': [100, 200, 300],
        'max_depth': [10, 20, None],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4]
    }
    model = RandomForestRegressor(random_state=42)
    grid_search = GridSearchCV(estimator=model, param_grid=param_grid, cv=5, scoring='neg_mean_absolute_error', n_jobs=-1, verbose=0)

    # 训练模型
    grid_search.fit(X_train, y_train)

    # 最优模型
    best_model = grid_search.best_estimator_

    # 预测
    y_pred = best_model.predict(X_test)

    # 计算 MAE
    mae = mean_absolute_error(y_test, y_pred)
    print(f"Mean Absolute Error (MAE) for adcode {adcode_value}: {mae:.2f}")

    # 将预测结果与实际值保存到 Excel 文件
    comparison = pd.DataFrame({'Actual Price': y_test.values, 'Predicted Price': y_pred})
    output_file_path = os.path.join(output_folder_path, f'prediction_result_{adcode_value}.xlsx')
    comparison.to_excel(output_file_path, index=False)
    print(f"预测结果已保存到 {output_file_path}")

print("所有区域的房价预测已完成！")
