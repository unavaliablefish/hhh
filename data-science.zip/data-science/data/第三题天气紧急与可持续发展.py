import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# 1. 导入数据
combined_file_path = r'D:\桌面\数维杯\Combined_City_Resilience_Scores.xlsx'  # 合并后的评分文件路径
combined_data = pd.read_excel(combined_file_path)

# 2. 分离 City 1 和 City 2 的数据
city1_data = combined_data[combined_data['City'] == 'City 1']
city2_data = combined_data[combined_data['City'] == 'City 2']

# 3. 定义不同的权重（针对极端天气、紧急事件和可持续发展）
# 极端天气下的服务类型权重
weather_weights = {
    'Accommodation Service': 0.05,
    'Business-Residential': 0.02,
    'Car': 0.02,
    'Finance And Insurance': 0.02,
    'Food And Beverage Service': 0.03,
    'Geographical Name And Address Information': 0.02,
    'Government And Social Organizations': 0.1,
    'Lifestyle Service': 0.03,
    'Medical And Health': 0.3,
    'Motorbike': 0.01,
    'Public Facilities': 0.15,
    'Retail Service': 0.02,
    'Science, Education, And Culture': 0.02,
    'Sports And Leisure': 0.01,
    'Transportation Facilities': 0.2
}

# 紧急事件下的服务类型权重
emergency_weights = {
    'Accommodation Service': 0.02,
    'Business-Residential': 0.03,
    'Car': 0.15,
    'Finance And Insurance': 0.02,
    'Food And Beverage Service': 0.15,
    'Geographical Name And Address Information': 0.01,
    'Government And Social Organizations': 0.2,
    'Lifestyle Service': 0.01,
    'Medical And Health': 0.3,
    'Motorbike': 0.01,
    'Public Facilities': 0.05,
    'Retail Service': 0.02,
    'Science, Education, And Culture': 0.01,
    'Sports And Leisure': 0.01,
    'Transportation Facilities': 0.1
}

# 可持续发展方面的服务类型权重
sustainability_weights = {
    'Accommodation Service': 0.03,
    'Business-Residential': 0.05,
    'Car': 0.02,
    'Finance And Insurance': 0.1,
    'Food And Beverage Service': 0.04,
    'Geographical Name And Address Information': 0.02,
    'Government And Social Organizations': 0.05,
    'Lifestyle Service': 0.1,
    'Medical And Health': 0.1,
    'Motorbike': 0.01,
    'Public Facilities': 0.1,
    'Retail Service': 0.03,
    'Science, Education, And Culture': 0.15,
    'Sports And Leisure': 0.05,
    'Transportation Facilities': 0.15
}

# 4. 分别计算每个城市在不同权重下的韧性和可持续发展评分
def calculate_resilience_score(data, weights, scenario):
    # 初始化总得分
    total_resilience_score = 0.0

    # 遍历每一行数据，计算每个服务类型的加权得分并累加
    for index, row in data.iterrows():
        service_type = row['Service Type']
        
        # 获取情景对应的 TOPSIS 评分
        topsis_score = row[f'topsis_score_{scenario}']
        
        # 获取权重并计算加权得分
        weight = weights.get(service_type, 0)
        weighted_score = topsis_score * weight
        
        # 累加加权得分
        total_resilience_score += weighted_score
    
    # 返回总的韧性得分
    return total_resilience_score

# 分别计算每个情景下的评分
city1_weather_score = calculate_resilience_score(city1_data, weather_weights, 'extreme_weather')
city1_emergency_score = calculate_resilience_score(city1_data, emergency_weights, 'emergency')
city1_sustainability_score = calculate_resilience_score(city1_data, sustainability_weights, 'sustainable')

city2_weather_score = calculate_resilience_score(city2_data, weather_weights, 'extreme_weather')
city2_emergency_score = calculate_resilience_score(city2_data, emergency_weights, 'emergency')
city2_sustainability_score = calculate_resilience_score(city2_data, sustainability_weights, 'sustainable')

# 5. 输出结果（展示每个城市在不同场景下的得分）
def print_city_scores(city_name, weather_score, emergency_score, sustainability_score):
    print(f"\n{city_name} 分析结果:")
    print(f"应对极端天气的总韧性得分: {weather_score:.4f}")
    print(f"应对紧急事件的总韧性得分: {emergency_score:.4f}")
    print(f"可持续发展能力的总得分: {sustainability_score:.4f}")

print_city_scores('City 1', city1_weather_score, city1_emergency_score, city1_sustainability_score)
print_city_scores('City 2', city2_weather_score, city2_emergency_score, city2_sustainability_score)

# # 6. 使用柱状图进行可视化
# def plot_city_comparison(city1_scores, city2_scores, title, labels):
#     x = np.arange(len(labels))  # The label locations on the x-axis
#     width = 0.35  # The width of the bars

#     fig, ax = plt.subplots(figsize=(10, 6))  # 增加图表的尺寸
#     bars1 = ax.bar(x - width / 2, city1_scores, width, label='City 1', color='blue', alpha=0.7)
#     bars2 = ax.bar(x + width / 2, city2_scores, width, label='City 2', color='green', alpha=0.7)

#     ax.set_xlabel('Evaluation Dimension', fontsize=14)
#     ax.set_ylabel('Average Score', fontsize=14)
#     ax.set_title(title, fontsize=16)
#     ax.set_xticks(x)
#     ax.set_xticklabels(labels, fontsize=12)
#     ax.legend(fontsize=12)

#     plt.show()

# # 使用已计算的得分
# city1_scores = [
#     city1_weather_score,  # 直接使用最终得分而不是平均值
#     city1_emergency_score,
#     city1_sustainability_score
# ]
# city2_scores = [
#     city2_weather_score,
#     city2_emergency_score,
#     city2_sustainability_score
# ]

# # 绘制柱状图
# plot_city_comparison(
#     city1_scores, city2_scores,
#     'Comparison of Resilience and Sustainable Development Scores between Cities',
#     ['Extreme Weather', 'Emergency', 'Sustainable Development']
# )

# 7. 确定城市的具体弱点、关键发展领域以及投资计划
def identify_city_weaknesses(data, scenario):
    """根据场景识别每个城市在特定领域的弱点"""
    weaknesses = []

    # 迭代每个服务类型并检查得分
    for index, row in data.iterrows():
        service_type = row['Service Type']
        resilience_score = row[f'Resilience Score ({scenario})']
        
        # 假设我们将0.5设为得分的中位线，低于0.5的得分被认为是弱点
        if resilience_score < 0.5:
            weaknesses.append((service_type, resilience_score))

    return weaknesses

def print_investment_plan(city_name, weaknesses_extreme, weaknesses_emergency, weaknesses_sustainable):
    """打印投资计划"""
    print(f"\n{city_name} Investment Plan:")

    print("Short-term Investment Areas (focus on Extreme Weather and Emergency):")
    for service_type, score in weaknesses_extreme + weaknesses_emergency:
        print(f"- {service_type} (Current Score: {score:.2f})")

    print("\nLong-term Investment Areas (focus on Sustainable Development):")
    for service_type, score in weaknesses_sustainable:
        print(f"- {service_type} (Current Score: {score:.2f})")

# 识别两个城市的弱点
city1_weaknesses_extreme = identify_city_weaknesses(city1_data, 'extreme_weather')
city1_weaknesses_emergency = identify_city_weaknesses(city1_data, 'emergency')
city1_weaknesses_sustainable = identify_city_weaknesses(city1_data, 'sustainable')

city2_weaknesses_extreme = identify_city_weaknesses(city2_data, 'extreme_weather')
city2_weaknesses_emergency = identify_city_weaknesses(city2_data, 'emergency')
city2_weaknesses_sustainable = identify_city_weaknesses(city2_data, 'sustainable')

# 打印投资计划
print_investment_plan('City 1', city1_weaknesses_extreme, city1_weaknesses_emergency, city1_weaknesses_sustainable)
print_investment_plan('City 2', city2_weaknesses_extreme, city2_weaknesses_emergency, city2_weaknesses_sustainable)
