import os
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split, RandomizedSearchCV
from sklearn.metrics import mean_absolute_error
from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor
import warnings

# 忽略 UserWarning 警告
warnings.filterwarnings('ignore', category=UserWarning)

# 指定文件夹路径
input_folder_path = r'D:\桌面\数维杯\2.1'  # 包含所有文件的文件夹
output_folder_path = r'D:\桌面\数维杯\2.2'  # 用于保存预测结果的文件夹

# 获取所有 adcode 文件
file_list = [file for file in os.listdir(input_folder_path) if file.startswith("adcode2_") and file.endswith(".xlsx")]

# 超参数空间
param_grid = {
    'n_estimators': [100, 200, 300, 400],
    'max_depth': [10, 20, 30, None],
    'min_samples_split': [2, 5, 10],
    'min_samples_leaf': [1, 2, 4],
    'max_features': ['sqrt', 'log2', 0.5],  # 'auto' 改为合法的选项
    'bootstrap': [True, False]
}

# 遍历每个文件并进行预测
for file_name in file_list:
    # 获取当前文件的 adcode 值
    adcode_value = file_name.split('_')[1].split('.')[0]  # 获取 adcode 的值部分
    input_file_path = os.path.join(input_folder_path, file_name)
    
    # 读取数据
    data = pd.read_excel(input_file_path)

    # 去除异常值的方法：调整 IQR 方法
    num_columns = data.select_dtypes(include=['int64', 'float64']).columns
    for col in num_columns:
        Q1 = data[col].quantile(0.25)
        Q3 = data[col].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 2.0 * IQR  # 调整 IQR 倍数
        upper_bound = Q3 + 2.0 * IQR
        filtered_data = data[(data[col] >= lower_bound) & (data[col] <= upper_bound)]
        
        # 检查过滤后数据量，如果过少，则保留原数据
        if len(filtered_data) >= 20:  # 设置样本数量阈值为 20
            data = filtered_data

    # 检查数据是否为空
    if data.shape[0] < 1:
        print(f"数据不足，跳过文件 {file_name}")
        continue

    # 准备数据：分割特征和目标
    X = data.drop(columns=['Price (USD)', 'adcode'])
    y = data['Price (USD)']

    # 检查特征是否为空
    if len(X) == 0 or len(y) == 0:
        print(f"特征或目标数据为空，跳过文件 {file_name}")
        continue

    # 特征标准化
    scaler = StandardScaler()
    try:
        X_scaled = scaler.fit_transform(X)
    except ValueError as e:
        print(f"无法标准化特征，跳过文件 {file_name}，错误信息：{e}")
        continue

    # 拆分训练集和测试集
    if len(X) < 2:  # 检查是否有足够样本进行训练和测试
        print(f"样本过少无法拆分，跳过文件 {file_name}")
        continue

    X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2, random_state=42)

    # 随机森林模型 - 随机搜索超参数调优
    model = RandomForestRegressor(random_state=42)
    random_search = RandomizedSearchCV(estimator=model, param_distributions=param_grid, n_iter=20, cv=5,
                                       scoring='neg_mean_absolute_error', n_jobs=-1, verbose=0, random_state=42)

    # 训练模型
    try:
        random_search.fit(X_train, y_train)
    except ValueError as e:
        print(f"训练模型失败，跳过文件 {file_name}，错误信息：{e}")
        continue

    # 最优模型
    best_model = random_search.best_estimator_

    # 使用 XGBoost 模型进行比较
    xgb_model = XGBRegressor(objective='reg:squarederror', random_state=42)
    xgb_model.fit(X_train, y_train)
    y_pred_xgb = xgb_model.predict(X_test)
    mae_xgb = mean_absolute_error(y_test, y_pred_xgb)

    # 随机森林模型预测
    y_pred_rf = best_model.predict(X_test)
    mae_rf = mean_absolute_error(y_test, y_pred_rf)

    print(f"Random Forest MAE for adcode {adcode_value}: {mae_rf:.2f}")
    print(f"XGBoost MAE for adcode {adcode_value}: {mae_xgb:.2f}")

    # 比较模型性能，选择较好的模型结果
    if mae_rf < mae_xgb:
        final_model = best_model
        y_pred = y_pred_rf
    else:
        final_model = xgb_model
        y_pred = y_pred_xgb

    # 将预测结果与实际值保存到 Excel 文件
    comparison = pd.DataFrame({'Actual Price': y_test.values, 'Predicted Price': y_pred})
    output_file_path = os.path.join(output_folder_path, f'prediction_result_{adcode_value}.xlsx')
    comparison.to_excel(output_file_path, index=False)
    print(f"预测结果已保存到 {output_file_path}")

print("所有区域的房价预测已完成！")
