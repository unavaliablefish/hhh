import os
import pandas as pd

# 指定文件夹路径（包含所有清洗后的 adcode 文件）
input_folder_path = r'D:\桌面\数维杯\2.1'  # 请替换为实际文件夹路径

# 获取所有 adcode 文件的列表
file_list = [file for file in os.listdir(input_folder_path) if file.startswith("adcode2_") and file.endswith(".xlsx")]

# 初始化一个空的 DataFrame 来存储所有区的数据
combined_data = pd.DataFrame()

# 遍历每个文件并合并数据
for file_name in file_list:
    file_path = os.path.join(input_folder_path, file_name)
    # 读取当前文件的数据
    data = pd.read_excel(file_path)
    # 将数据合并到 combined_data
    combined_data = pd.concat([combined_data, data], ignore_index=True)

# 对合并后的数据按照 Community Number 进行排序
combined_data_sorted = combined_data.sort_values(by='Community Number')

# 重置索引，以便使数据保持整齐
combined_data_sorted.reset_index(drop=True, inplace=True)

# 确保合并后的数据一致
print(f"合并后的数据总行数：{combined_data.shape[0]}")  # 打印行数以确认合并后的数据量

# 保存合并后的文件（可选步骤，如果想保存为新文件）
combined_file_path = r'D:\桌面\数维杯\2.1\combined_city_data.xlsx'  # 保存路径
combined_data.to_excel(combined_file_path, index=False)
print(f"合并后的文件已保存到：{combined_file_path}")