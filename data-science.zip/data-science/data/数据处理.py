import os
import pandas as pd
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

def train_and_predict_for_all_areas(folder_path, target_column='Price (USD)', random_state=42):
    """
    对文件夹中每个区域的房价进行预测，并返回评估指标。
    
    Parameters:
    - folder_path: 文件夹路径，里面包含了多个区域的数据文件（Excel）
    - target_column: 目标变量，默认为 'Price (USD)'
    - random_state: 随机种子，默认为 42
    
    Returns:
    - results: 包含所有区域评估结果的字典，每个区域的评估指标（MAE、RMSE、R²）
    """
    
    # 存储所有区域的评估结果
    results = {}
    
    # 遍历文件夹中的所有 Excel 文件
    for file_name in os.listdir(folder_path):
        if file_name.endswith(".xlsx"):  # 确保文件是 Excel 文件
            area_code = file_name.split("_")[1].split(".")[0]  # 获取 adcode 部分
            
            # 读取当前区域的 Excel 文件
            area_data = pd.read_excel(os.path.join(folder_path, file_name))
            
            # 选择特征和目标变量
            X = area_data.drop(columns=[target_column, 'adcode'])  # 去掉目标列和区域列
            y = area_data[target_column]  # 房价列
            
            # 创建并训练随机森林回归模型
            model = RandomForestRegressor(random_state=random_state)
            model.fit(X, y)
            
            # 对该区域数据进行预测
            predictions = model.predict(X)
            
            # 计算评估指标
            mae = mean_absolute_error(y, predictions)  # 平均绝对误差
            rmse = np.sqrt(mean_squared_error(y, predictions))  # 均方根误差
            r2 = r2_score(y, predictions)  # 决定系数
            
            # 存储当前区域的评估结果
            results[area_code] = {
                'MAE': mae,
                'RMSE': rmse,
                'R²': r2
            }
            
            # 可选：输出前几个预测结果，供检查
            result_sample = pd.DataFrame({
                'True Price': y.head(),
                'Predicted Price': predictions[:len(y)],
            })
            print(f"\n区域 {area_code} 的预测结果：")
            print(result_sample.head())
            
    return results


# 使用示例
folder_path = r'D:\桌面\数维杯\1\adcode1_220103.xlsx'  # 请替换为实际文件夹路径

# 运行预测函数
results = train_and_predict_for_all_areas(folder_path)

# 输出各区域的评估结果
for area_code, metrics in results.items():
    print(f"\n区域 {area_code} 的评估结果:")
    print(f"MAE (Mean Absolute Error): {metrics['MAE']}")
    print(f"RMSE (Root Mean Squared Error): {metrics['RMSE']}")
    print(f"R² (R-squared): {metrics['R²']}")
